package server;




public class start{
	
	
	/*public static void main(String[] args){
		String value1;
		String value2;
		 String port="4907";

		value1="123";
		 
		new InitConnection(Integer.parseInt(port),value1);
		
	}*/
}
