package client;


import javax.swing.*;

import java.awt.*;

import java.awt.event.*;

import java.io.DataInputStream;

import java.io.DataOutputStream;

import java.io.IOException;

import java.net.Socket;

public class Authenticate {
			private Socket cSocket = null;
			DataOutputStream psswrchk = null;
			DataInputStream verification = null;
			String verify ="";
			JButton SUBMIT;
			JPanel panel;
			JLabel label, label1;
			String width="",height="";
			final JTextField text1;

			
			
			
Authenticate(Socket cSocket){
				label1=new JLabel();
		 
				text1 = new JTextField(15);
				this.cSocket = cSocket;
		
				
				
	String value1="123";
				
				try{
				psswrchk= new DataOutputStream(cSocket.getOutputStream());
				verification= new DataInputStream(cSocket.getInputStream());
				psswrchk.writeUTF(value1);
				verify=verification.readUTF();
	
				}catch (IOException e){
				e.printStackTrace();
				}

				if(verify.equals("valid")){
				try{
					
				width = verification.readUTF();
				height = verification.readUTF();
		
				}catch (IOException e){
				e.printStackTrace();		
				}
				CreateFrame abc= new CreateFrame(cSocket,width,height);
				 
				}
				else {
				System.out.println("enter the valid password");
				
				}




 
 


 
			
	}
}

