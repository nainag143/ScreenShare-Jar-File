package client;


import java.net.Socket;

import javax.swing.JOptionPane;

public class Start{
	static String port = "4907";

/*	public static void main(String args[]){
			 initialize("172.18.3.218", Integer.parseInt(port));
			}
*/
	public static void initialize(String ip, int port){
			try{
				
				Socket sc = new Socket(ip,port);
				System.out.println("Connecting to the Server");
				//Authenticate class is responsible for security purposes
				Authenticate frame1= new Authenticate(sc);
	
				 
			} catch (Exception ex){
				ex.printStackTrace();
			}
					           }
		}



